<?php
	header('Content-type: application/json');
	if(!isset($_GET['id'])) {
		echo json_encode(NULL);
		exit();
	}

	$url = "http://testenv-mbksgmvdzg.elasticbeanstalk.com/services/";
	$url .= $_GET['id'];
	$url .= "?access_token=e7cd657f-8cf9-4ecb-b536-74784ff8d7c2";
	$c = curl_init();
	curl_setopt($c, CURLOPT_URL, $url);
	curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($c, CURLOPT_TIMEOUT, 60);
	
	$res = curl_exec($c);
	if($res == "null") {
		echo json_encode(NULL);
	}else {
		echo $res;
	}
	exit();
?>